Problem statement:

https://workat.tech/machine-coding/practice/design-library-management-system-jgjrv8q8b136

https://docs.google.com/document/d/1GBtDtj90BQFgP7cQF8DyDX8BeHQ3KjIRZS1UGmXAFFY/edit#heading=h.qpyh6rwx1iaz